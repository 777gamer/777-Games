# 777 Games

A responsive, Steam-inspired browser game library.

## Run it locally
1. Download and unzip the folder.
2. Open `index.html` in a modern browser.
3. Click **Add game** and enter the HTTPS URL of a browser-playable game you own or are authorized to embed.

Two original mini-games are built in: Neon Clicker and Star Dodge.

## Publish free with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a new public repository, for example `777-games`.
3. Upload `index.html` to the repository's top level (the repository root).
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then Save.
7. Wait for GitHub Pages to publish. Your site address will appear in the Pages section.

## Add games
Use the **Add game** button on the site. Enter a game title, category, and a publicly accessible HTTPS browser-game URL. The game host must permit embedding in an iframe; some sites block this, in which case link to their official page instead.

Custom games are saved in this browser's local storage. That means entries are local to the browser/device and are not automatically shared with visitors. For a shared public catalog, edit the `starterGames` array in `index.html` and add authorized game URLs there.

## Rights and safety
Do not upload or redistribute commercial game files or use unauthorized copies. Only host/embed games you created, own, or have permission to distribute. Use official links for titles that do not offer an authorized browser version.
